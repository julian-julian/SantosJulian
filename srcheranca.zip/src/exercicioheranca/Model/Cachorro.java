/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioheranca.Model;

/**
 *
 * @author thiago.65542
 */
public class Cachorro extends Mamifero{

    public Cachorro(boolean latemuito, String nome) {
        super(nome);
        this.latemuito = latemuito;
    }
    
    
     
    private boolean latemuito;

    public boolean isLatemuito() {
        return latemuito;
    }

    public void setLatemuito(boolean latemuito) {
        this.latemuito = latemuito;
    }
    
    public void setLateAlto(){
        this.latemuito =true;
    }
    
    public void setLateBaixo(){
        this.latemuito =false;
    }
    
    @Override
    public void talk(){
        System.out.println("AU! AU!");
    }
}
