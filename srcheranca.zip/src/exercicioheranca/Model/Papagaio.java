/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioheranca.Model;

/**
 *
 * @author thiago.65542
 */
public class Papagaio extends Passaro{
    
    private String vocabulario;

    public Papagaio(String vocabulario, String nome) {
        super(nome);
        this.vocabulario = vocabulario;
    }

    public String getVocabulario() {
        return vocabulario;
    }

    public void setVocabulario(String vocabulario) {
        this.vocabulario = vocabulario;
    }
    @Override
    public void talk(){
        System.out.println("O meu vocabulario é "+this.vocabulario);
    }
    
}
