/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioheranca.Model;

/**
 *
 * @author thiago.65542
 */
public class Animal {
    
    private String nome;

    public Animal(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    public void imp(){
        System.out.println("O nome do animal é "+this.nome+" e sou um "+this.getClass().getSimpleName());
    }
    public void talk(){
        System.out.println("Me not falar");
    }
    
}
