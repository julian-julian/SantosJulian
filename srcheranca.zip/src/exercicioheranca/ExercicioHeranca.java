/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicioheranca;

import exercicioheranca.Model.Animal;
import exercicioheranca.Model.BemTeVi;
import exercicioheranca.Model.Cachorro;
import exercicioheranca.Model.Mamifero;
import exercicioheranca.Model.Papagaio;
import exercicioheranca.Model.Passaro;
import exercicioheranca.Model.Vaca;

/**
 *
 * @author thiago.65542
 */
public class ExercicioHeranca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Vaca vaca = new Vaca("Vaca");
        vaca.talk();
        vaca.imp();
        Papagaio papa= new Papagaio("abcd", "Casa grande");
        papa.talk();
        papa.imp();
        Mamifero mami = new Mamifero("Mami");
        mami.talk();
        mami.imp();
        Passaro pasa = new Passaro("Pasa");
        pasa.talk();
        pasa.imp();
        Cachorro cacho = new Cachorro(false, "Miau");
        cacho.talk();
        cacho.imp();
        BemTeVi btv = new BemTeVi("Bent");
        btv.talk();
        btv.imp();
        Animal ani = new Animal("Ani");
        ani.talk();
        ani.imp();
    }
    
}
